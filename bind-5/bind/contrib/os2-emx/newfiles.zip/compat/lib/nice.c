#ifndef LINT
static char rcsid[] = "$Id: nice.c,v 8.1 1996/06/08 06:23:51 seawi Exp $";
#endif

/*
 * nice() emulation routine for EMX/GCC OS/2
 */

#ifdef __EMX__

#define PRIO_PROCESS 1

int setpriority(int class, int id, int priority)
{
  return 0;
};

int getpriority(int class, int id)
{
  return 0;
};

int nice(int increment)
{
  int old = getpriority (PRIO_PROCESS, 0);
  setpriority (PRIO_PROCESS, 0, old + increment);
  return old + increment;
};
#endif
