#ifndef LINT
static char rcsid[] = "$Id: rename_unixstyle.c,v 8.1 1996/06/08 06:23:51 seawi Exp $";
#endif

/*
 * unix-style rename() routine for EMX/GCC OS/2;
 * if target already exists, it will be overwritten
 */

#ifdef __EMX__

#include <io.h>
#include <unistd.h>

int rename_unixstyle(const char *old_name, const char *new_name)
{
  int result;
  if (result = rename(old_name, new_name) != 0)
  {
    if (access(new_name, W_OK) == 0) remove(new_name);
    result = rename(old_name, new_name);
  }
  return result;
};

#endif
